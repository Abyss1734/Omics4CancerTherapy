library(ggplot2)
library(readr)
library(dplyr)
library(ggrepel)

# Функция для загрузки генов из CSV
load_special_genes <- function(path) {
  if (file.exists(path)) {
    genes_df <- read_csv(path)
    return(genes_df$Gene)
  } else {
    warning(paste("Файл не найден:", path))
    return(character(0))
  }
}

# Функция для создания графика
create_cancer_plot <- function(data_path, cancer_type, highlight_genes, special_genes_path, output_folder) {
  # Загрузка данных
  data <- read_csv(data_path)
  data <- na.omit(data)
  colnames(data) <- c("Gene", "Zscore", "Expression")
  
  # Загрузка специальных генов
  special_genes <- load_special_genes(special_genes_path)
  
  # Определение цветовой схемы
  if (cancer_type == "ALL") {
    normal_color <- "#9ECAE1"  # Светло-голубой
    highlight_color <- "#E6550D"  # Темно-синий
    special_color <- "#31a354"  # Зеленый
  } else if (cancer_type == "AML") {
    normal_color <- "#FDAE6B"  # Светло-оранжевый
    highlight_color <- "#3182BD"  # Темно-оранжевый
    special_color <- "#31a354"  # Зеленый
  }
  
  # Создание графика с правильным порядком слоев
  p <- ggplot(data, aes(x = Expression, y = Zscore)) +
    # 1. Обычные точки (самый нижний слой)
    geom_point(
      data = subset(data, !(Gene %in% c(highlight_genes, special_genes))),
      color = normal_color,
      size = 2.5,
      alpha = 0.6,
      shape = 16
    ) +
    # 2. Зеленые точки (из CSV, средний слой)
    geom_point(
      data = subset(data, Gene %in% special_genes),
      color = special_color,
      size = 2.5,
      alpha = 0.8,
      shape = 16
    ) +
    # 3. Выделенные точки (из списков, верхний слой точек)
    geom_point(
      data = subset(data, Gene %in% highlight_genes),
      color = highlight_color,
      size = 3,
      alpha = 1,
      shape = 16
    ) +
    # 4. Подписи генов (самый верхний слой)
    geom_text_repel(
      data = subset(data, Gene %in% highlight_genes),
      aes(label = Gene),
      color = highlight_color,
      size = 5,
      fontface = "bold",
      box.padding = 0.5,
      max.overlaps = Inf,
      segment.color = "grey50"
    ) +
    labs(
      title = paste("Gene Expression vs Z-score:", cancer_type),
      x = "Mean Expression",
      y = "Z-score"
    ) +
    theme_minimal(base_size = 14) +
    theme(
      plot.title = element_text(hjust = 0.5, face = "bold", size = 16),
      axis.title = element_text(face = "bold", size = 12),
      panel.grid.major = element_line(color = "grey90"),
      panel.grid.minor = element_blank(),
      panel.background = element_rect(fill = "white", color = NA)
    )
  
  # Сохранение графика
  output_path <- file.path(output_folder, paste0(cancer_type, "_expression_zscore_plot.png"))
  ggsave(
    output_path,
    plot = p,
    width = 10,
    height = 8,
    dpi = 300,
    bg = "white"
  )
  
  return(p)
}

# Пути к данным
data_folder <- "C:/Users/rusla/OneDrive/Рабочий стол/r2"
all_special_path <- "C:/Users/rusla/OneDrive/Рабочий стол/Диплом/Гены/thresholds/gene_selection/ALL/ALL_depscore_-0.15_zscore_-1.csv"
aml_special_path <- "C:/Users/rusla/OneDrive/Рабочий стол/Диплом/Гены/thresholds/gene_selection/AML/AML_depscore_-0.15_zscore_-0.5.csv"

# Гены для выделения
highlight_genes_ALL <- c("ATP1B3", "BCL2", "CDK6", "COL18A1", "DHODH", "DNMT1", "ERG", "FKBP1A",
                         "FLT3", "GART", "HMGB1", "MAGEA3", "MLST8", "NAMPT", "NOTCH1", "PIK3CD",
                         "PPAT", "RPS26", "SYK", "TFRC", "TKT", "TYMS", "UMPS")

highlight_genes_AML <- c("ANO1", "ATP1B3", "BCL2", "BMPR1B", "CDK6", "CSF2RB", "CTGF", "DHODH",
                         "FLT3", "GLS", "GUCY1B2", "HMGB1", "JAK2", "KDM1A", "MAP2K1", "MPL",
                         "NAMPT", "PIK3CD", "PTPN11", "RAF1", "RPL12", "RPL13A", "RPL17", "RPL21",
                         "RPL26", "RPL28", "RPL38", "RPL4", "RPS24", "RPS28", "SCN11A", "SV2C",
                         "TERT", "TYK2", "UMPS")

# Создание графиков
all_plot <- create_cancer_plot(
  file.path(data_folder, "ALL_expression_with_zscore.csv"),
  "ALL",
  highlight_genes_ALL,
  all_special_path,
  data_folder
)

aml_plot <- create_cancer_plot(
  file.path(data_folder, "AML_expression_with_zscore.csv"),
  "AML",
  highlight_genes_AML,
  aml_special_path,
  data_folder
)

# Вывод графиков
print(all_plot)
print(aml_plot)

message("Графики успешно сохранены в: ", data_folder)