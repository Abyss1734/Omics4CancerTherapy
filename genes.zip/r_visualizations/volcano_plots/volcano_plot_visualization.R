library(ggplot2)
library(ggrepel)
library(readr)

# Загрузка данных
data <- read_csv("C:/Users/rusla/OneDrive/Рабочий стол/Диплом/Гены/correlations/correlation_pim-447_bosutinib/correlation_bosutinib_auc_vs_depscore/bosutinib_depscore_lung_cancer_literature_genes.csv")

# Извлечение названия из последнего столбца
last_col_name <- names(data)[ncol(data)]
plot_title <- last_col_name
file_name <- paste0("./", tolower(last_col_name), ".png")

# Преобразование p-значений
data$neg_log_pval <- -log10(data$Spearman_P_value)

# Убираем NA в нужных столбцах
data <- data[!is.na(data$Spearman_Correlation) & !is.na(data$Spearman_P_value), ]

# Построение вулкано-графика с черными границами точек
ggplot(data, aes(x = Spearman_Correlation, y = neg_log_pval)) + 
  geom_point(
    aes(fill = Spearman_P_value < 0.05),  # заливка зависит от p-value
    size = 3, 
    shape = 21,           # форма 21 поддерживает заливку (fill) и обводку (color)
    color = "black",      # черная граница
    stroke = 0.5          # толщина границы
  ) +
  scale_fill_manual(
    values = c("gray", "red"),
    labels = c("p ≥ 0.05", "p < 0.05"),
    name = "Significance"
  ) +
  geom_hline(
    aes(yintercept = -log10(0.05), linetype = "p = 0.05 hard"),
    color = "red", 
    linewidth = 0.8
  ) +
  geom_vline(
    aes(xintercept = -0.4, linetype = "R = ±0.4 soft"),
    color = "blue", 
    linewidth = 0.8
  ) +
  geom_vline(
    aes(xintercept = 0.4, linetype = "R = ±0.4 soft"),
    color = "blue", 
    linewidth = 0.8
  ) +
  scale_linetype_manual(
    name = "Thresholds",
    values = c("p = 0.05 hard" = "33", "R = ±0.4 soft" = "22")
  ) +
  geom_label_repel(
    data = subset(data, Spearman_P_value < 0.05),
    aes(label = Gene), 
    size = 3, 
    max.overlaps = 30,
    box.padding = 0.5
  ) +
  labs(
    title = plot_title,
    x = "Spearman Correlation (R)",
    y = expression("-log"[10]*"P-value")
  ) +
  theme_light() +
  theme(
    axis.line = element_line(size = 1),
    axis.title = element_text(size = 16),
    axis.text = element_text(size = 14),
    plot.title = element_text(size = 20, hjust = 0.5),
    legend.title = element_text(size = 14),
    legend.text = element_text(size = 12)
  ) +
  ylim(0, max(data$neg_log_pval, na.rm = TRUE) * 1.1) +
  xlim(-1, 1)

# Сохранение графика
ggsave(file_name, 
       width = 10, height = 8, dpi = 300, units = "in")
